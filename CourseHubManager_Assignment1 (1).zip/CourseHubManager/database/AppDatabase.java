package CourseHubManager.database;

import androidx.room.Database;
import androidx.room.RoomDatabase;

import CourseHubManager.entities.*;
import CourseHubManager.dao.*;

@Database(entities = {User.class, Course.class, Category.class, Lesson.class, Enrollment.class, Bookmark.class}, version = 1)
public abstract class AppDatabase extends RoomDatabase {
    public abstract UserDao userDao();
    public abstract CourseDao courseDao();
    public abstract CategoryDao categoryDao();
    public abstract LessonDao lessonDao();
    public abstract EnrollmentDao enrollmentDao();
    public abstract BookmarkDao bookmarkDao();
}
