package CourseHubManager.viewmodel;

import android.app.Application;
import androidx.lifecycle.AndroidViewModel;
import java.util.List;
import CourseHubManager.entities.Course;
import CourseHubManager.repository.CourseRepository;

public class CourseViewModel extends AndroidViewModel {
    private CourseRepository repository;

    public CourseViewModel(Application application) {
        super(application);
        repository = new CourseRepository(application);
    }

    public List<Course> getCoursesByCategory(int categoryId) {
        return repository.getCoursesByCategory(categoryId);
    }
}
