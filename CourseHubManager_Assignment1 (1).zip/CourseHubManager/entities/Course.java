package CourseHubManager.entities;

import androidx.room.Entity;
import androidx.room.PrimaryKey;

@Entity
public class Course {
    @PrimaryKey(autoGenerate = true)
    public int id;
    public String title;
    public String description;
    public String instructor;
    public String imageUrl;
    public double price;
    public int hours;
    public int categoryId;
}
