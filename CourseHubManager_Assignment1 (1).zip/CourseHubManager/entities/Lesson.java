package CourseHubManager.entities;

import androidx.room.Entity;
import androidx.room.PrimaryKey;

@Entity
public class Lesson {
    @PrimaryKey(autoGenerate = true)
    public int id;
    public int courseId;
    public String title;
    public String description;
    public String youtubeLink;
}
