package CourseHubManager.entities;

import androidx.room.Entity;
import androidx.room.PrimaryKey;

@Entity
public class Enrollment {
    @PrimaryKey(autoGenerate = true)
    public int id;
    public int userId;
    public int courseId;
    public boolean isCompleted;
}
