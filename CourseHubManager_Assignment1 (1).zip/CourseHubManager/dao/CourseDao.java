package CourseHubManager.dao;

import androidx.room.*;
import java.util.List;
import CourseHubManager.entities.Course;

@Dao
public interface CourseDao {
    @Insert
    void insert(Course course);

    @Query("SELECT * FROM Course WHERE categoryId = :categoryId")
    List<Course> getCoursesByCategory(int categoryId);
}
