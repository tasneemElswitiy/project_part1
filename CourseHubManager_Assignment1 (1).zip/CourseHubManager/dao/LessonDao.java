package CourseHubManager.dao;

import androidx.room.*;
import java.util.List;
import CourseHubManager.entities.Lesson;

@Dao
public interface LessonDao {
    @Insert
    void insert(Lesson lesson);

    @Query("SELECT * FROM Lesson WHERE courseId = :courseId")
    List<Lesson> getLessonsForCourse(int courseId);
}
