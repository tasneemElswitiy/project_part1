package CourseHubManager.dao;

import androidx.room.*;
import java.util.List;
import CourseHubManager.entities.Category;

@Dao
public interface CategoryDao {
    @Insert
    void insert(Category category);

    @Query("SELECT * FROM Category")
    List<Category> getAll();
}
