package CourseHubManager.dao;

import androidx.room.*;
import java.util.List;
import CourseHubManager.entities.Bookmark;

@Dao
public interface BookmarkDao {
    @Insert
    void insert(Bookmark bookmark);

    @Query("SELECT * FROM Bookmark WHERE userId = :userId")
    List<Bookmark> getBookmarks(int userId);

    @Delete
    void delete(Bookmark bookmark);
}
