package CourseHubManager.dao;

import androidx.room.*;
import java.util.List;
import CourseHubManager.entities.Enrollment;

@Dao
public interface EnrollmentDao {
    @Insert
    void insert(Enrollment enrollment);

    @Query("SELECT * FROM Enrollment WHERE userId = :userId")
    List<Enrollment> getUserEnrollments(int userId);
}
