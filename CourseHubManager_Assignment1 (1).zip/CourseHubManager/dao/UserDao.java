package CourseHubManager.dao;

import androidx.room.*;
import java.util.List;
import CourseHubManager.entities.User;

@Dao
public interface UserDao {
    @Insert
    void insert(User user);

    @Query("SELECT * FROM User WHERE email = :email AND password = :password")
    User login(String email, String password);
}
