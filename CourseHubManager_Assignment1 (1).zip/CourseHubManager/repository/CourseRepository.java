package CourseHubManager.repository;

import android.app.Application;
import androidx.lifecycle.LiveData;
import java.util.List;

import CourseHubManager.dao.CourseDao;
import CourseHubManager.database.AppDatabase;
import CourseHubManager.entities.Course;

public class CourseRepository {
    private CourseDao courseDao;

    public CourseRepository(Application application) {
        AppDatabase db = AppDatabaseInstance.getInstance(application);
        courseDao = db.courseDao();
    }

    public List<Course> getCoursesByCategory(int categoryId) {
        return courseDao.getCoursesByCategory(categoryId);
    }
}
