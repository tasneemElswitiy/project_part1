package CourseHubManager.ui;

import android.os.Bundle;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
import CourseHubManager.R;

public class CourseDetailsActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_course_details);

        TextView txtTitle = findViewById(R.id.txtCourseTitle);
        TextView txtDescription = findViewById(R.id.txtCourseDescription);
        TextView txtInstructor = findViewById(R.id.txtCourseInstructor);
        TextView txtPrice = findViewById(R.id.txtCoursePrice);
        // Set course data from intent extras or database
    }
}
