package CourseHubManager.ui;

import android.os.Bundle;
import androidx.fragment.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import androidx.lifecycle.ViewModelProvider;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import CourseHubManager.viewmodel.CourseViewModel;
import CourseHubManager.R;

public class HomeFragment extends Fragment {

    private CourseViewModel courseViewModel;

    public HomeFragment() {}

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_home, container, false);

        RecyclerView recyclerView = view.findViewById(R.id.recyclerCourses);
        recyclerView.setLayoutManager(new LinearLayoutManager(getContext()));

        courseViewModel = new ViewModelProvider(this).get(CourseViewModel.class);
        // Connect RecyclerView with data when available

        return view;
    }
}
